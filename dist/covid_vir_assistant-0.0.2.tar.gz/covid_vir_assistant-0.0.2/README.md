A small example about virtual assistant like Siri/ Google assistant. By using wolframalpha and wikipedia as references so that please visit  wolframalpha and create application to using it. Be focus on how to use speech_recognition and UI text-to-spech, I hope you can familar with python syntax and love python more.
How to use it?
1. Please  run pip install covid-vir-assistant
2. Run file __init__.py / covid_vir_assistant.py 
3. Leave anything what you need help 
    ex: I want to search 'Thomas Edison'. So you can type 'Thomas Edison' on this box or Press enter and say 'Thomas Edison'. 
4. Please wait and see what covid virtual assistant can do for you.

Visit my github and do not hesitate to leave me comment via email.
